
Setting up MySQL README:

 * Add the csv files to: C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/
 * There must be 5 .csV files
 * Run the files in the following order:
 * ProjectDDL.sql, ProjectInsert.sql, EnsureDataConsistency.sql, CreateDBUsers.sql, PhysicalDesign.sql, and After.sql


JDBC Project README:

 * Run MainJDBCProject for COMS363 Final Project
 * Make sure to add the mysql-connector-java-8.0.22.jar to as a dependency
 * Java Project is built using Intellij on Java version 11.
 * Follow instructions on screen while running to execute project tasks. 
 * @authors Shubham Sharma and Brayden Ruch
 * DB LOGIN INFO:
 * Username: cs363
 * Password: 363F2020
 
 
 Questions?
 Reach out to the group members for any issues with setting up the project/code. 
 