-- author group 105 
-- Brayden Ruch
-- Shubham Sharma
SET SQL_SAFE_UPDATES=0;
use group105;
UPDATE users SET state = 'AL' WHERE state like 'ALABAMA';
UPDATE users SET state = 'AK' WHERE state like 'Alaska';
UPDATE users SET state = 'AZ' WHERE state like 'ARIZONA';
UPDATE users SET state = 'AR' WHERE state like 'ARKANSAS';
UPDATE users SET state = 'CA' WHERE state like 'CALIFORNIA';
UPDATE users SET state = 'CO' WHERE state like 'COLORADO';
UPDATE users SET state = 'CT' WHERE state like 'CONNECTICUT';
UPDATE users SET state = 'DE' WHERE state like 'DELAWARE';
UPDATE users SET state = 'FL' WHERE state like 'FLORIDA';
UPDATE users SET state = 'GA' WHERE state like 'GEORGIA';

UPDATE users SET state = 'HI' WHERE state like 'HAWAII';
UPDATE users SET state = 'ID' WHERE state like 'IDAHO';
UPDATE users SET state = 'IL' WHERE state like 'ILLINOIS';
UPDATE users SET state = 'IA' WHERE state like 'IOWA';
UPDATE users SET state = 'KS' WHERE state like 'KANSAS';
UPDATE users SET state = 'KY' WHERE state like 'KENTUCKY';
UPDATE users SET state = 'LA' WHERE state like 'LOUISIANA';
UPDATE users SET state = 'ME' WHERE state like 'MAINE';
UPDATE users SET state = 'MD' WHERE state like 'MARYLAND';
UPDATE users SET state = 'MA' WHERE state like 'MASSACHUSETTS';

UPDATE users SET state = 'MI' WHERE state like 'MICHIGAN';
UPDATE users SET state = 'MN' WHERE state like 'MINNESOTA';
UPDATE users SET state = 'MS' WHERE state like 'MISSISSIPPI';
UPDATE users SET state = 'MO' WHERE state like 'MISSOURI';
UPDATE users SET state = 'MT' WHERE state like 'MONTANA';
UPDATE users SET state = 'NE' WHERE state like 'NEBRASKA';
UPDATE users SET state = 'NV' WHERE state like 'NEVADA';
UPDATE users SET state = 'NH' WHERE state like 'NEW HAMPSHIRE';
UPDATE users SET state = 'NJ' WHERE state like 'NEW JERSEY';
UPDATE users SET state = 'NM' WHERE state like 'NEW MEXICO';

UPDATE users SET state = 'NY' WHERE state like 'NEW YORK';
UPDATE users SET state = 'NC' WHERE state like 'NORTH CAROLINA';
UPDATE users SET state = 'ND' WHERE state like 'NORTH DAKOTA';
UPDATE users SET state = 'OH' WHERE state like 'OHIO';
UPDATE users SET state = 'OK' WHERE state like 'OKLAHOMA';
UPDATE users SET state = 'OR' WHERE state like 'OREGON';
UPDATE users SET state = 'PA' WHERE state like 'PENNSYLVANIA';
UPDATE users SET state = 'RI' WHERE state like 'RHODE ISLAND';
UPDATE users SET state = 'SC' WHERE state like 'SOUTH CAROLINA';
UPDATE users SET state = 'SD' WHERE state like 'SOUTH DAKOTA';

UPDATE users SET state = 'TN' WHERE state like 'TENNESSEE';
UPDATE users SET state = 'TX' WHERE state like 'TEXAS';
UPDATE users SET state = 'UT' WHERE state like 'UTAH';
UPDATE users SET state = 'VT' WHERE state like 'VERMONT';
UPDATE users SET state = 'VA' WHERE state like 'VIRGINIA';
UPDATE users SET state = 'WA' WHERE state like 'WASHINGTON';
UPDATE users SET state = 'WV' WHERE state like 'WEST VIRGINIA';
UPDATE users SET state = 'IN' WHERE state like 'INDIANA';
UPDATE users SET state = 'WI' WHERE state like 'WISCONSIN';
UPDATE users SET state = 'WY' WHERE state like 'WYOMING';

SET SQL_SAFE_UPDATES=1;
